import boto3

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    # reference existing table:
    rds = boto3.client('rds')
    comprehend = boto3.client('comprehend')

    #Describe where DB is available and on what port
    db = rds.describe_db_instances()['DBInstances'][0]
    ENDPOINT = db['Endpoint']['Address']
    PORT = db['Endpoint']['Port']
    DBID = db['DBInstanceIdentifier']
    db_url = 'mysql+mysqlconnector://{}:{}@{}:{}/a2q2'.format('username','password', ENDPOINT, PORT)
    db_tweets = dataset.connect(db_url)

    for tweet in event: 
        response = comprehend.detect_sentiment(Text=tweet['text'],
                                           LanguageCode='en')
        sentiment = response['Sentiment'] 
        sentiment_score = response['SentimentScore']

        db_tweets['tweets_table'].upsert({'sentiment' : sentiment,
                            'sentiment_score' : sentiment_score,
                            }, ['tweet_id'])

    return {'StatusCode': 200}