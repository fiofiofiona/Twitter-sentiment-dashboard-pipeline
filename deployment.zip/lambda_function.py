import boto3
import tweepy
import json

def get_twitter_keys() -> dict:
    """Retrieve secrets from Parameter Store."""
    # Create our SSM Client.
    aws_client = boto3.client('ssm',  region_name = 'us-east-1')

    # Get our keys from Parameter Store.
    parameters = aws_client.get_parameters(
        Names=[
            'consumer_key',
            'consumer_secret',
            'access_token',
            'access_token_secret'
        ],
        WithDecryption=True
    )

    # Convert list of parameters into simpler dict.
    keys = {}
    for parameter in parameters['Parameters']:
        keys[parameter['Name']] = parameter['Value']

    return keys


def lambda_handler(event, context):
    """Main Lambda function."""

    keys = get_twitter_keys()
    auth = tweepy.OAuth1UserHandler(consumer_key=keys.get('consumer_key'), 
                                    consumer_secret=keys.get('consumer_secret'), 
                                    access_token=keys.get('access_token'),
                                    access_token_secret=keys.get('access_token_secret'))
    api = tweepy.API(auth)
    response = api.search_tweets('abortion', lang = 'en', result_type = 'mixed')
    return json.dumps(response, default=str)
